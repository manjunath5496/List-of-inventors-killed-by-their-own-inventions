#ifndef CLASS_H
#define CLASS_H

#include <string>
 
class Class {
  
  std::string name;

 public:
  Class(std::string name);
  std::string getName();  
  
};

#endif  // CLASS_H
